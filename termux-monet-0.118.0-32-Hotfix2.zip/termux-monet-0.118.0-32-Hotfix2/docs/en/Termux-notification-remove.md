Remove a notification previously shown with "termux-notification --id".

## Usage

termux-notification-remove \[id\]

Notification id is a value previously used to show notification with
command "termux-notification".

## See Also

[Termux:API](Termux:API) - Termux addon that exposes device
functionality as API to command line programs.