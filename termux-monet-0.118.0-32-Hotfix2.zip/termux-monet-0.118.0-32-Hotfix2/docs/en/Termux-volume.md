Change volume of specified audio stream.

## Usage

termux-volume \[stream\] \[volume\]

Valid audio streams are: alarm, music, notification, ring, system, call.

Call w/o arguments to show information about each audio stream (output
format is json).

## See Also

[Termux:API](Termux:API) - Termux addon that exposes device
functionality as API to command line programs.