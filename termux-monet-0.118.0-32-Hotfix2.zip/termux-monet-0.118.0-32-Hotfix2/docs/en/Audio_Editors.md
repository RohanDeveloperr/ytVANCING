Audio editing software is software which allows editing and generating
of audio data. Audio editing software can be implemented completely or
partly as library, as computer application, as Web application or as a
loadable kernel module.

## [ffmpeg](ffmpeg)
