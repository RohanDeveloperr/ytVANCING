Toggle LED Torch on device.

## Usage

termux-torch \[on \| off\]

Program accepts a one of these values:

- on - enable torch.
- off - disable torch.

## See Also

[Termux:API](Termux:API) - Termux addon that exposes device
functionality as API to command line programs.