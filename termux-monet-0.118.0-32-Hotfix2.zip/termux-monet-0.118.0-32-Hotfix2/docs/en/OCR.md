Available OCR (Optical Character Recognition) packages for Termux
available on-the-fly are:

Package: ocrad 

Description: Optical Character Recognition program based on a feature
extraction method 
Homepage:<http://www.gnu.org/software/ocrad/ocrad.html>

Package: ocrad-dev 

Description: Development files for ocrad 
Homepage:<http://www.gnu.org/software/ocrad/ocrad.html>

Package: tesseract 

Description: Tesseract is probably the most accurate open source OCR
engine available  Homepage: https://github.com/tesseract-ocr/tesseract

Package: tesseract-dev 

Description: Development files for tesseract 
Homepage: https://github.com/tesseract-ocr/tesseract

There probably are more OCR programs available as [Ruby
gems,](Ruby) [Python pips,](Python) [Perl
cpan](Perl) and similar.

# See Also

- [Other Package
  Managers](Package_Management#Other_Package_Managers)