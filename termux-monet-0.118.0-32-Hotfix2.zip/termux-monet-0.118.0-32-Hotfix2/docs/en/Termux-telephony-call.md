Call a telephony number.

## Usage

termux-telephony-call \[number\]

Requires a telephony number specified in appropriate format.

## See Also

[Termux:API](Termux:API) - Termux addon that exposes device
functionality as API to command line programs.