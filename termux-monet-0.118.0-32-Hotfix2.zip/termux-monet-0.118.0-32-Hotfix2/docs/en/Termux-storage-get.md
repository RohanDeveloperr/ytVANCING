Request a file from the system and write it to the specified file.

## Usage

termux-storage-get \[output-file\]

Output file is mandatory argument. Also, make sure that specified path
is writable.

## See Also

[Termux:API](Termux:API) - Termux addon that exposes device
functionality as API to command line programs.