Use fingerprint sensor on device to check for authentication.

## Usage

This program does not take any arguments.

Output is returned in json format.

## Note

This API is available only for devices running Android 6 (Marshmallow)
or higher.

## See Also

[Termux:API](Termux:API) - Termux addon that exposes device
functionality as API to command line programs.