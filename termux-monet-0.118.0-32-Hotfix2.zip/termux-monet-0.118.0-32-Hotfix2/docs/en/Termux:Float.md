This addon provides the Termux console in a floating window.

![](images/Termux_float.png)

The usage and installation documentation is available at
<https://github.com/termux/termux-float>.