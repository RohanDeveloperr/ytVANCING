Vibrate the device.

## Usage

termux-vibrate \[options\]

### Options

`-d duration  the duration to vibrate in ms (default:1000)`
`-f           force vibration even in silent mode`

## See Also

[Termux:API](Termux:API) - Termux addon that exposes device
functionality as API to command line programs.