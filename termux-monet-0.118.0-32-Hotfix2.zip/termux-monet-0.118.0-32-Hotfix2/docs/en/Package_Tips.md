Some packages are troublesome to get working or configure in Termux.
Follow the individual page to get installation and configuration help.

- [mariadb](MariaDB)
- [postgresql](postgresql)

If you are interested in resolving issues regarding packages, please
post at <https://github.com/termux/termux-packages/issues> and search
your topic before posting to avoid duplicates, please. You might even
find your question answered before asking.

# See Also

[Package Management: Other
PackagenManagers](Package_Management#Other_Package_Managers)