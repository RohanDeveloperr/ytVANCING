Toggles Wi-Fi on/off.

## Usage

termux-wifi-enable \[true \| false\]

Program accepts a one of these values:

- true - enable Wi-Fi
- false - disable Wi-Fi

## See Also

[Termux:API](Termux:API) - Termux addon that exposes device
functionality as API to command line programs.