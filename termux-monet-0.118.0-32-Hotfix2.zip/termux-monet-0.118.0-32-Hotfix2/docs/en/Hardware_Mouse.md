You can almost do anything you can do with a hardware mouse on the
touchscreen, i.e. a virtual mouse.

# See Also

- [Screen Gestures](Screen_Gestures)
- [Hardware Keyboard](Hardware_Keyboard)
- [OTG](OTG)
- [Touch Keyboard](Touch_Keyboard)