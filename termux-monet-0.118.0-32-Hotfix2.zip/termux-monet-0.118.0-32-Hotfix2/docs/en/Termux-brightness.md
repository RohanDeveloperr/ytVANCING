Set the display brightness. Note that this may not work if automatic
brightness control is enabled.

## Usage

termux-brightness \[brightness\]

Brightness value should be between 0 and 255 or auto.

## See Also

[Termux:API](Termux:API) - Termux addon that exposes device
functionality as API to command line programs.