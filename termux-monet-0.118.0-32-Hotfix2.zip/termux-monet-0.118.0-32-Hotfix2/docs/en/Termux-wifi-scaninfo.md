Retrieves last wifi scan information.

## Usage

This program does not take any arguments.

Output is returned in json format.

## Note

This API does not perform scanning. Instead, it retrieves information
about last scan done by Android OS.

## See Also

[Termux:API](Termux:API) - Termux addon that exposes device
functionality as API to command line programs.