Scan the specified file(s) and add to the media content provider.

## Usage

termux-media-scan \[-v\] \[-r\] file \[file...\]

Output displayed in plain text (informational message).

### Options

`-r  scan directories recursively`
`-v  verbose mode`

## See Also

[Termux:API](Termux:API) - Termux addon that exposes device
functionality as API to command line programs.