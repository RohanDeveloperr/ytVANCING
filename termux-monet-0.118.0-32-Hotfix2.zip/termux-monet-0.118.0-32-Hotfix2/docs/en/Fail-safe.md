1.  REDIRECT [Recover a broken
    environment](Recover_a_broken_environment)