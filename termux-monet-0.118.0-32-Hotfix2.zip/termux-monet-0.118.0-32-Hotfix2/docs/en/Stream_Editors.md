A Unix utility that parses and transforms text, using a simple, compact
programming language. Options for doing "stream editing" include awk,
node.js, perl and sed.

## gawk

Programming language designed for text processing

Homepage: <https://www.gnu.org/software/gawk/>

## sed

GNU stream text editor

Homepage: <https://www.gnu.org/software/sed/>