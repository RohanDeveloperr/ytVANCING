Get the system clipboard text.

## Usage

This program does not take any arguments.

Output is returned in plain text.

## See Also

[Termux:API](Termux:API) - Termux addon that exposes device
functionality as API to command line programs.