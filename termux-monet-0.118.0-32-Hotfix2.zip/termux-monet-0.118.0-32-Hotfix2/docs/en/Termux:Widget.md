A Termux plugin app to run scripts in Termux with launcher shortcuts and
widgets.

![](images/Termux_widget.png)

The usage and installation documentation is available at
<https://github.com/termux/termux-widget>.