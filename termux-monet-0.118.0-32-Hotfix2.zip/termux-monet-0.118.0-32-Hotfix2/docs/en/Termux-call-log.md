Print the phone call history.

## Usage

termux-call-log \[options\]

Output displayed in json format.

### Options

`-l limit   offset in call log list (default: 10)`
`-o offset  offset in call log list (default: 0)`

## See Also

[Termux:API](Termux:API) - Termux addon that exposes device
functionality as API to command line programs.