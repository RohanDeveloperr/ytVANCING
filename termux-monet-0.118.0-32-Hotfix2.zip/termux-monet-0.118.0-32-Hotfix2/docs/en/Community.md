Any questions after reading the [FAQ](FAQ)? Consider joining
us with a cup of herbal tea, and similar. Termux is a distributed
community worldwide. Here are a few ways to get in touch:

## Official communities

- **Homepage** : <https://termux.dev/>
- **Github** : <https://github.com/termux/>
- **Gitter** : <https://gitter.im/termux/termux>
- **Discord** : <https://discord.gg/HXpF69X>
- **[IRC](IRC)** : Channel \#Termux on
  [libera.chat](https://libera.chat/)
- **Email** : [termux+subscribe@groups.io](https://groups.io/g/termux)
- **Reddit** : <https://www.reddit.com/r/termux>
- **Facebook** : <https://facebook.com/termux/>
- **Twitter** : <https://twitter.com/termuxdevs>
- **Telegram** : <https://telegram.me/termux24x7>
- **YouTube** :
  <https://www.youtube.com/channel/UCGCVyLywi5KfW6n-54tiiJQ>

### Rules

## Other (non-official) communities

Here is a list of non-official communities. Termux developers are not
responsible about any information or misinformation, site links and
files distributed in these communities.

- **Facebook Group** : <https://facebook.com/groups/termux/>
- **Telegram Chinese community**: <https://telegram.me/Termux_CN/>
- **Telegram Ethiopian community**:
  <https://telegram.me/Et_Termux_community/>
- **Telegram Spanish community**: <https://t.me/termux_es>
- **QQ Chinese community**: <https://jq.qq.com/?_wv=1027&k=ylRxQK7Z>

# See Also

- [Development](Development)