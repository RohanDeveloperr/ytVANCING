Get the status of the device battery.

## Usage

This program does not take any arguments.

Output is returned in json format.

## See Also

[Termux:API](Termux:API) - Termux addon that exposes device
functionality as API to command line programs.