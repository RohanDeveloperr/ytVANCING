Termux has some extra features. You can add them by installing addons:

- [Termux:API](Termux:API): Access Android and Chrome hardware features.
- [Termux:Boot](Termux:Boot): Run script(s) when your device boots.
- [Termux:Float](Termux:Float): Run Termux in a floating window.
- [Termux:Styling](Termux:Styling): Have color schemes and powerline-ready fonts customize the appearance of the Termux terminal.
- [Termux:Tasker](Termux:Tasker): An easy way to call Termux executables from Tasker and compatible apps.
- [Termux:Widget](Termux:Widget): Start small scriptlets from the home screen.
