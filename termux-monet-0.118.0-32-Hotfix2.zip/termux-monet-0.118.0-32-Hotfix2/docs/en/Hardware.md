[Hardware Keyboard](Hardware_Keyboard): How to control Termux with a hardware keyboard
[Hardware Mouse](Hardware_Mouse) : How to control Termux with a hardware mouse
[Internal and External Storage](Internal_and_external_storage): Accessing Files in shared storage and on SD Card

# See Also

- [OTG](OTG)