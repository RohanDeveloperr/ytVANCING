With video editors various Video manipulation can be done, including:
cutting, converting, splitting, joining ...

## [ffmpeg](ffmpeg)