[Emacstutor](Emacstutor) is an interactive hands-on which
will familiarize you with many things in Emacs.

[Vimtutor](Vimtutor) is designed to describe enough of the
commands that you will be able to easily use Vim as an all-purpose
editor.

# See Also

- [FAQ](FAQ)