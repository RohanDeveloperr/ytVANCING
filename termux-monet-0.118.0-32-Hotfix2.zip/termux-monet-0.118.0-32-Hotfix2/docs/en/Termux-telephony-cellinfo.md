Get information about all observed cell information from all radios on
the device including the primary and neighboring cells.

## Usage

This program does not take any arguments.

Output is returned in json format.

## See Also

[Termux:API](Termux:API) - Termux addon that exposes device
functionality as API to command line programs.